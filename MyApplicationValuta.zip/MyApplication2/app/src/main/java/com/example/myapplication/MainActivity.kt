package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var inputAmount: EditText
    private lateinit var fromCurrency: Spinner
    private lateinit var toCurrency: Spinner
    private lateinit var convertButton: Button
    private lateinit var resultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputAmount = findViewById(R.id.inputAmount)
        fromCurrency = findViewById(R.id.fromCurrency)
        toCurrency = findViewById(R.id.toCurrency)
        convertButton = findViewById(R.id.convertButton)
        resultText = findViewById(R.id.resultText)

        // Создание массива валют
        val currencies = arrayOf("RUB", "USD", "EUR")

        // Адаптер для Spinner
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, currencies)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        fromCurrency.adapter = adapter
        toCurrency.adapter = adapter

        convertButton.setOnClickListener { convertCurrency() }
    }

    private fun convertCurrency() {
        val amountStr = inputAmount.text.toString()
        if (amountStr.isNotEmpty()) {
            val amount = amountStr.toDouble()
            val fromCurrencyValue = fromCurrency.selectedItem.toString()
            val toCurrencyValue = toCurrency.selectedItem.toString()

            var result = 0.0

            // Конвертация в RUB
            result = when (fromCurrencyValue) {
                "USD" -> amount * 75 // USD в RUB
                "EUR" -> amount * 85 // EUR в RUB
                else -> amount // RUB остается RUB
            }

            // Конвертация из RUB
            result = when (toCurrencyValue) {
                "USD" -> result / 75 // RUB в USD
                "EUR" -> result / 85 // RUB в EUR
                else -> result // RUB остается RUB
            }

            resultText.text = String.format("Результат: %.2f %s", result, toCurrencyValue)
        } else {
            resultText.text = "Введите сумму для конверсии."
        }
    }
}